# Estado base comun - sin cambios
