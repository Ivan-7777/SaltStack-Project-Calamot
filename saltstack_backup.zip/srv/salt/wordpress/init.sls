include:
  - webserver.content
  - BDD

# Instalar WP-CLI
descargar_wpcli:
  cmd.run:
    - name: curl -L https://raw.githubusercontent.com/wp-cli/builds/gh-pages/phar/wp-cli.phar -o /tmp/wp-cli.phar
    - creates: /usr/local/bin/wp

instalar_wpcli:
  cmd.run:
    - name: chmod +x /tmp/wp-cli.phar && mv /tmp/wp-cli.phar /usr/local/bin/wp
    - onchanges:
      - cmd: descargar_wpcli
    - require:
      - cmd: descargar_wpcli

# Descargar WordPress
descargar_wordpress:
  cmd.run:
    - name: wp core download --path={{ pillar['web-server']['webroot'] }} --allow-root --locale=es_ES
    - unless: test -f {{ pillar['web-server']['webroot'] }}/wp-load.php
    - require:
      - cmd: instalar_wpcli
      - file: crear_webroot

# Generar wp-config.php
configurar_wordpress:
  cmd.run:
    - name: |
        wp config create           --path={{ pillar['web-server']['webroot'] }}           --dbname={{ pillar['wordpress']['db_name'] }}           --dbuser={{ pillar['wordpress']['db_user'] }}           --dbpass='{{ pillar['wordpress']['db_pass'] }}'           --dbhost=localhost           --allow-root
    - unless: test -f {{ pillar['web-server']['webroot'] }}/wp-config.php
    - require:
      - cmd: descargar_wordpress

# Realizar la instalacion automatica
instalar_wordpress_core:
  cmd.run:
    - name: |
        wp core install           --path={{ pillar['web-server']['webroot'] }}           --url=http://{{ pillar['web-server']['domain'] }}           --title='{{ pillar['wordpress']['title'] }}'           --admin_user={{ pillar['wordpress']['admin_user'] }}           --admin_password={{ pillar['wordpress']['admin_pass'] }}           --admin_email={{ pillar['wordpress']['admin_email'] }}           --allow-root
    - unless: wp core is-installed --path={{ pillar['web-server']['webroot'] }} --allow-root
    - require:
      - cmd: configurar_wordpress

# Ajustar permisos despues de todo
permisos_finales_wordpress:
  file.directory:
    - name: {{ pillar['web-server']['webroot'] }}
    - user: www-data
    - group: www-data
    - recurse:
      - user
      - group
    - require:
      - cmd: instalar_wordpress_core

# Crear pagina de bienvenida personalizada
crear_pagina_bienvenida:
  cmd.run:
    - name: |
        wp post create --path={{ pillar['web-server']['webroot'] }}           --post_type=page           --post_title='Pagina de Bienvenida'           --post_content='Bienvenidos a la infraestructura TecnoXarxa estabilizada por Antigravity.'           --post_status=publish           --allow-root
    - unless: wp post list --path={{ pillar['web-server']['webroot'] }} --post_type=page --field=post_title --allow-root | grep 'Pagina de Bienvenida'
    - require:
      - cmd: instalar_wordpress_core

# Establecer como pagina de inicio
establecer_inicio:
  cmd.run:
    - name: |
        PAGE_ID=$(wp post list --path={{ pillar['web-server']['webroot'] }} --post_type=page --title='Pagina de Bienvenida' --field=ID --allow-root)
        wp option update show_on_front page --path={{ pillar['web-server']['webroot'] }} --allow-root
        wp option update page_on_front $PAGE_ID --path={{ pillar['web-server']['webroot'] }} --allow-root
    - require:
      - cmd: crear_pagina_bienvenida
