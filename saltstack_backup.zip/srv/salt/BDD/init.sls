# MariaDB - Gestión de Base de Datos
mariadb_server_installed:
  pkg.installed:
    - name: mariadb-server

mariadb_client_installed:
  pkg.installed:
    - name: mariadb-client

python_mysql:
  pkg.installed:
    - name: python3-mysqldb

mariadb_bind_address:
  file.replace:
    - name: /etc/mysql/mariadb.conf.d/50-server.cnf
    - pattern: "^bind-address\\s*=\\s*127\\.0\\.0\\.1"
    - repl: "bind-address = 0.0.0.0"
    - require:
      - pkg: mariadb_server_installed
    - onlyif: test -f /etc/mysql/mariadb.conf.d/50-server.cnf

mariadb_service_running:
  service.running:
    - name: mariadb
    - enable: True
    - require:
      - pkg: mariadb_server_installed

set_root_password:
  cmd.run:
    - name: |
        mysql -u root -e "
          ALTER USER \"root\"@\"localhost\" IDENTIFIED VIA mysql_native_password USING PASSWORD(\"{{ salt["pillar.get"]("mysql:root_password", "Unclick2026") }}\");
          FLUSH PRIVILEGES;
        "
    - unless: mysql -u root -p"{{ salt["pillar.get"]("mysql:root_password", "Unclick2026") }}" -e "SELECT 1" 2>/dev/null
    - require:
      - service: mariadb_service_running
    - onlyif: which mysql

create_zabbix_db:
  cmd.run:
    - name: |
        mysql -u root -p"{{ salt["pillar.get"]("mysql:root_password", "Unclick2026") }}" -e "
          CREATE DATABASE IF NOT EXISTS {{ salt["pillar.get"]("zabbix:db_name", "zabbix") }} CHARACTER SET utf8mb4 COLLATE utf8mb4_bin;
          CREATE USER IF NOT EXISTS \"{{ salt["pillar.get"]("zabbix:db_user", "zabbix") }}\"@\"%\" IDENTIFIED BY \"{{ salt["pillar.get"]("zabbix:db_pass", "Unclick2026") }}\";
          ALTER USER \"{{ salt["pillar.get"]("zabbix:db_user", "zabbix") }}\"@\"%\" IDENTIFIED BY \"{{ salt["pillar.get"]("zabbix:db_pass", "Unclick2026") }}\";
          GRANT ALL PRIVILEGES ON {{ salt["pillar.get"]("zabbix:db_name", "zabbix") }}.* TO \"{{ salt["pillar.get"]("zabbix:db_user", "zabbix") }}\"@\"%\";
          FLUSH PRIVILEGES;
        "
    - unless: mysql -u {{ salt["pillar.get"]("zabbix:db_user", "zabbix") }} -p"{{ salt["pillar.get"]("zabbix:db_pass", "Unclick2026") }}" -e "status" 2>/dev/null
    - require:
      - cmd: set_root_password
    - onlyif: which mysql

create_salt_logs_db:
  cmd.run:
    - name: mysql -u root -p"{{ salt["pillar.get"]("mysql:root_password", "Unclick2026") }}" -e "CREATE DATABASE IF NOT EXISTS salt_logs;"
    - unless: mysql -u root -p"{{ salt["pillar.get"]("mysql:root_password", "Unclick2026") }}" -e "USE salt_logs;" 2>/dev/null
    - require:
      - cmd: set_root_password
    - onlyif: which mysql

create_saltlogger_user:
  cmd.run:
    - name: |
        mysql -u root -p"{{ salt["pillar.get"]("mysql:root_password", "Unclick2026") }}" -e "
          CREATE USER IF NOT EXISTS \"saltlogger\"@\"%\" IDENTIFIED BY \"{{ salt["pillar.get"]("mysql:password", "Unclick2026") }}\";
          ALTER USER \"saltlogger\"@\"%\" IDENTIFIED BY \"{{ salt["pillar.get"]("mysql:password", "Unclick2026") }}\";
          GRANT ALL PRIVILEGES ON salt_logs.* TO \"saltlogger\"@\"%\";
          FLUSH PRIVILEGES;
        "
    - unless: mysql -u saltlogger -p"{{ salt["pillar.get"]("mysql:password", "Unclick2026") }}" -h 127.0.0.1 -e "SELECT 1" 2>/dev/null
    - require:
      - cmd: create_salt_logs_db
    - onlyif: which mysql

create_backup_table:
  cmd.run:
    - name: |
        mysql -u saltlogger -p"{{ salt["pillar.get"]("mysql:password", "Unclick2026") }}" -h 127.0.0.1 salt_logs -e "
          CREATE TABLE IF NOT EXISTS machine_backups (
            id INT AUTO_INCREMENT PRIMARY KEY,
            hostname VARCHAR(255) NOT NULL,
            backup_path VARCHAR(512) NOT NULL,
            status ENUM(\"success\", \"fail\") NOT NULL,
            execution_time DATETIME NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_hostname (hostname),
            INDEX idx_status (status),
            INDEX idx_execution_time (execution_time)
          ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
        "
    - unless: mysql -u saltlogger -p"{{ salt["pillar.get"]("mysql:password", "Unclick2026") }}" -h 127.0.0.1 salt_logs -e "DESCRIBE machine_backups;" 2>/dev/null
    - require:
      - cmd: create_saltlogger_user
    - onlyif: which mysql

create_wordpress_db:
  cmd.run:
    - name: |
        mysql -u root -p"{{ salt["pillar.get"]("mysql:root_password", "Unclick2026") }}" -e "
          CREATE DATABASE IF NOT EXISTS {{ salt["pillar.get"]("wordpress:db_name", "wordpress") }};
          CREATE USER IF NOT EXISTS \"{{ salt["pillar.get"]("wordpress:db_user", "wordpress") }}\"@\"%\" IDENTIFIED BY \"{{ salt["pillar.get"]("wordpress:db_pass", "WordPress_2026!") }}\";
          GRANT ALL PRIVILEGES ON {{ salt["pillar.get"]("wordpress:db_name", "wordpress") }}.* TO \"{{ salt["pillar.get"]("wordpress:db_user", "wordpress") }}\"@\"%\";
          FLUSH PRIVILEGES;
        "
    - require:
      - cmd: set_root_password
    - onlyif: which mysql
