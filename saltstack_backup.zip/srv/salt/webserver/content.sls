instalar_apache:
  pkg.installed:
    - name: apache2

instalar_php:
  pkg.installed:
    - name: php
    - pkgs:
      - php
      - libapache2-mod-php
      - php-mysql

crear_webroot:
  file.directory:
    - name: {{ pillar['web-server']['webroot'] }}
    - user: www-data
    - group: www-data
    - mode: 755
    - makedirs: True
    - require:
      - pkg: instalar_apache

configurar_vhost:
  file.managed:
    - name: /etc/apache2/sites-available/server.es.conf
    - contents: |
        <VirtualHost *:80>
            ServerName {{ pillar['web-server']['domain'] }}
            DocumentRoot {{ pillar['web-server']['webroot'] }}
            ErrorLog ${APACHE_LOG_DIR}/error.log
            CustomLog ${APACHE_LOG_DIR}/access.log combined
        </VirtualHost>
    - require:
      - pkg: instalar_apache

habilitar_vhost:
  cmd.run:
    - name: a2ensite server.es.conf && a2dissite 000-default.conf
    - onchanges:
      - file: configurar_vhost

index_php:
  file.managed:
    - name: {{ pillar['web-server']['webroot'] }}/index.php
    - contents: |
        <h1>Hola desde {{ pillar['web-server']['domain'] }}</h1>
        <?php phpinfo(); ?>
    - user: www-data
    - group: www-data
    - mode: 644
    - require:
      - file: crear_webroot

apache_service:
  service.running:
    - name: apache2
    - enable: True
    - watch:
      - file: configurar_vhost
      - cmd: habilitar_vhost
