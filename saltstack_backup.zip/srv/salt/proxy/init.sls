instalar_nginx:
  pkg.installed:
    - name: nginx

configurar_proxy:
  file.managed:
    - name: /etc/nginx/sites-available/default
    - source: salt://proxy/files/proxy.conf.jinja
    - template: jinja
    - user: root
    - group: root
    - mode: 644
    - require:
      - pkg: instalar_nginx

configurar_red_proxy:
  file.managed:
    - name: /etc/network/interfaces
    - contents: |
        auto lo
        iface lo inet loopback

        auto enp0s3
        iface enp0s3 inet static
            address {{ pillar["proxy"]["ip"] }}/24
            gateway {{ pillar["firewall"]["dmz"]["ip"] }}

configurar_dns_proxy:
  file.managed:
    - name: /etc/resolv.conf
    - contents: |
        nameserver {{ pillar["firewall"]["dmz"]["ip"] }}
        nameserver 8.8.8.8

nginx_service:
  service.running:
    - name: nginx
    - enable: True
    - watch:
      - file: configurar_proxy

aplicar_red_proxy:
  cmd.run:
    - name: systemctl restart networking
    - onchanges:
      - file: configurar_red_proxy
