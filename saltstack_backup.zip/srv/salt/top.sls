base:
  "*":
    - common
  minion-05:
    - firewall
    - dns
  minion-04:
    - proxy
  minion-02:
    - wordpress
  minion-08:
    - wireguard
