#!/bin/bash
# WireGuard
wg-quick down wg0 2>/dev/null || true
systemctl stop wg-quick@wg0 2>/dev/null || true
systemctl disable wg-quick@wg0 2>/dev/null || true
systemctl reset-failed 2>/dev/null || true
DEBIAN_FRONTEND=noninteractive apt-get purge -y wireguard-tools 2>/dev/null || true
rm -rf /etc/wireguard
# Apache/PHP (por si acaso)
systemctl stop apache2 2>/dev/null || true
systemctl disable apache2 2>/dev/null || true
DEBIAN_FRONTEND=noninteractive apt-get purge -y apache2 apache2-bin libapache2-mod-php* php* 2>/dev/null || true
rm -rf /var/www/user /etc/apache2/sites-available/server.es.conf
# sysctl
sed -i "/net.ipv4.ip_forward/d" /etc/sysctl.conf
sysctl -p 2>/dev/null || true
apt-get autoremove -y 2>/dev/null || true
echo "MINION-02 FULL LIMPIO"
