#!/bin/bash
systemctl stop apache2 mariadb 2>/dev/null
systemctl disable apache2 mariadb 2>/dev/null
DEBIAN_FRONTEND=noninteractive apt-get purge -y apache2 apache2-bin libapache2-mod-php* php* mariadb-server mariadb-client 2>/dev/null
apt-get autoremove -y 2>/dev/null
rm -rf /var/www/user /etc/apache2/sites-available/server.es.conf
# Restaurar interfaces a DHCP
cat > /etc/network/interfaces << IFACES
source /etc/network/interfaces.d/*
auto lo
iface lo inet loopback
allow-hotplug enp0s3
auto enp0s3
iface enp0s3 inet dhcp
IFACES
hostnamectl set-hostname minion-02 2>/dev/null
echo "MINION-02 LIMPIO"
