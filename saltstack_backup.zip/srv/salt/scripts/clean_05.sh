#!/bin/bash
for svc in nftables isc-dhcp-relay bind9; do
  systemctl stop $svc 2>/dev/null
  systemctl disable $svc 2>/dev/null
done
DEBIAN_FRONTEND=noninteractive apt-get purge -y nftables isc-dhcp-relay bind9 bind9-utils bind9-dnsutils 2>/dev/null
apt-get autoremove -y 2>/dev/null
rm -f /etc/nftables.conf /etc/default/isc-dhcp-relay
rm -rf /etc/bind/zones /etc/bind/named.conf.local /etc/bind/named.conf.options
sed -i "/net.ipv4.ip_forward/d" /etc/sysctl.conf
sysctl -p 2>/dev/null
echo "MINION-05 LIMPIO"
