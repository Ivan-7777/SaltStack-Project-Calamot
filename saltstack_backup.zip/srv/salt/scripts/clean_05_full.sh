#!/bin/bash
systemctl stop nftables isc-dhcp-relay bind9 2>/dev/null || true
systemctl disable nftables isc-dhcp-relay bind9 2>/dev/null || true
DEBIAN_FRONTEND=noninteractive apt-get purge -y nftables isc-dhcp-relay bind9 bind9-utils bind9-dnsutils 2>/dev/null || true
apt-get autoremove -y 2>/dev/null || true
rm -f /etc/nftables.conf /etc/default/isc-dhcp-relay
rm -rf /etc/bind/zones /etc/bind/named.conf.local /etc/bind/named.conf.options
sed -i "/net.ipv4.ip_forward/d" /etc/sysctl.conf
sysctl -p 2>/dev/null || true
echo "MINION-05 FULL LIMPIO"
