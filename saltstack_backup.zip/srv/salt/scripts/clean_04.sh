#!/bin/bash
systemctl stop nginx 2>/dev/null
systemctl disable nginx 2>/dev/null
DEBIAN_FRONTEND=noninteractive apt-get purge -y nginx nginx-common nginx-full 2>/dev/null
apt-get autoremove -y 2>/dev/null
rm -f /etc/nginx/sites-available/default /etc/nginx/sites-enabled/default
# Restaurar interfaces a DHCP
cat > /etc/network/interfaces << IFACES
source /etc/network/interfaces.d/*
auto lo
iface lo inet loopback
allow-hotplug enp0s3
auto enp0s3
iface enp0s3 inet dhcp
IFACES
echo "MINION-04 LIMPIO"
