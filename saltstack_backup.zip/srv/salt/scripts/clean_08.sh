#!/bin/bash
wg-quick down wg0 2>/dev/null || true
systemctl stop wg-quick@wg0 nftables 2>/dev/null || true
systemctl disable wg-quick@wg0 nftables 2>/dev/null || true
DEBIAN_FRONTEND=noninteractive apt-get purge -y wireguard-tools 2>/dev/null || true
apt-get autoremove -y 2>/dev/null || true
rm -rf /etc/wireguard
sed -i "/net.ipv4.ip_forward/d" /etc/sysctl.conf
sysctl -p 2>/dev/null || true
echo "MINION-08 LIMPIO"
