#!/bin/bash
cat >> /etc/wireguard/wg0.conf << PEEREOF

[Peer]
PublicKey = +wQDiwImHcvcqiugDVoS3atvlcJV6ukAFkR84nF9uDU=
AllowedIPs = 10.66.66.2/32
PEEREOF
wg syncconf wg0 <(wg-quick strip wg0)
echo "PEER ADDED"
wg show
