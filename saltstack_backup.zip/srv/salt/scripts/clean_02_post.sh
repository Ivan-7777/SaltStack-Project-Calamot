#!/bin/bash
systemctl stop apache2 2>/dev/null
systemctl disable apache2 2>/dev/null
DEBIAN_FRONTEND=noninteractive apt-get purge -y apache2 apache2-bin libapache2-mod-php* php* 2>/dev/null
apt-get autoremove -y 2>/dev/null
rm -rf /var/www/user /etc/apache2/sites-available/server.es.conf
hostnamectl set-hostname minion-02 2>/dev/null
echo "MINION-02 POST-CLEAN"
