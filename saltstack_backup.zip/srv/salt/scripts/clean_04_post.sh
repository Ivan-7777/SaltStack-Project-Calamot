#!/bin/bash
systemctl stop nginx 2>/dev/null
systemctl disable nginx 2>/dev/null
DEBIAN_FRONTEND=noninteractive apt-get purge -y nginx nginx-common 2>/dev/null
apt-get autoremove -y 2>/dev/null
rm -f /etc/nginx/sites-available/default /etc/nginx/sites-enabled/default
echo "MINION-04 POST-CLEAN"
