base:
  minion-05:
    - customers.aitor.main
  minion-04:
    - customers.aitor.main
  minion-02:
    - customers.aitor.main
  minion-08:
    - customers.aitor.main
