firewall:
  wan:
    ip: 10.1.105.47
    mask: 24
    gateway: 10.1.105.1
    interface: enp0s3
  lan:
    ip: 192.168.0.1
    mask: 24
    interface: enp0s8
  dmz:
    ip: 192.168.1.1
    mask: 24
    interface: enp0s9
dns:
  recursion: true
  allow_query: "127.0.0.1; localhost; 192.168.0.0/24; 192.168.1.0/24; 10.1.105.0/24; 10.66.66.0/24"
  forwarders:
    - 8.8.8.8
service_mapping:
  minion-05:
    - firewall
    - dns
  minion-04:
    - proxy
  minion-02:
    - webserver
  minion-08:
    - wireguard
network_nodes:
  minion-05:
    interfaces:
      -
        ip: 10.1.105.47
        mask: 24
        gateway: 10.1.105.1
        name: enp0s3
  minion-02:
    interfaces:
      -
        ip: 192.168.0.10
        mask: 24
        gateway: 192.168.0.1
        name: enp0s3
  minion-04:
    interfaces:
      -
        ip: 192.168.1.10
        mask: 24
        gateway: 192.168.1.1
        name: enp0s3
  minion-07:
    interfaces:
      -
        ip: 192.168.0.123
        mask: 24
        gateway: 192.168.0.1
        name: enp0s3
  minion-08:
    interfaces:
      -
        ip: 192.168.0.151
        mask: 24
        gateway: 192.168.0.1
        name: enp0s3
proxy:
  ip: 192.168.1.10
  puerto_customizado: 80
  interface: enp0s3
  mask: 24
web-server:
  hostname: "serv-web"
  domain: server.es
  webroot: /var/www/user/server/html
  network:
    address: 192.168.0.10
    mask: 24
    gateway: 192.168.0.1
    dns: 192.168.0.1
    interface: enp0s3
wireguard:
  port: 51820
  address: 10.66.66.1/24
  static_lan_ip: 192.168.0.151/24
  wan_interface: enp0s3
  peers: {}
