wireguard:
  address: 10.66.66.1/24
  port: 60600
  wan_interface: enp0s3
  service_enabled: true
