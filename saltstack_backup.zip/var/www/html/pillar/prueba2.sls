customer:
  name: prueba2
network:
  lan: 192.168.0.0/24
  dmz: 10.0.2.0/16
services:
  nginx:
    enabled: true
    port: 443
  vpn:
    clients: 10
