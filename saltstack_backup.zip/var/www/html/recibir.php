<?php
// require_once "auth.php";
// check_auth();

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    http_response_code(405);
    die("POST requerido");
}

function sanitize_name($value) {
    return preg_replace('/[^a-zA-Z0-9_-]/', '_', strtolower(trim((string)$value)));
}

function post_bool($value) {
    return in_array(strtolower((string)$value), ["1", "true", "yes", "on"], true);
}

function yaml_scalar($value) {
    if (is_bool($value)) return $value ? "true" : "false";
    if (is_int($value) || is_float($value)) return (string)$value;
    if ($value === null) return "null";
    $string = (string)$value;
    if ($string === "" || preg_match('/[:#\\-\\{\\}\\[\\],&\\*\\?\\|><=!%@]/', $string) || preg_match('/\\s/', $string)) {
        return '"' . str_replace('"', '\\"', $string) . '"';
    }
    return $string;
}

function yaml_key($key) {
    $string = (string)$key;
    if ($string === "" || preg_match('/^[*&#?!%@`]|[:{}\\[\\],]|^\s|\s$/', $string) || preg_match('/\\s/', $string)) {
        return '"' . str_replace('"', '\\"', $string) . '"';
    }
    return $string;
}

function array_to_yaml($data, $indent = 0) {
    $yaml = "";
    $prefix = str_repeat("  ", $indent);
    $is_list = array_keys($data) === range(0, count($data) - 1);
    foreach ($data as $key => $value) {
        if ($is_list) {
            if (is_array($value)) {
                $yaml .= $prefix . "-" . PHP_EOL . array_to_yaml($value, $indent + 1);
            } else {
                $yaml .= $prefix . "- " . yaml_scalar($value) . PHP_EOL;
            }
            continue;
        }
        if (is_array($value)) {
            if ($value === []) {
                $yaml .= $prefix . yaml_key($key) . ": {}" . PHP_EOL;
            } else {
                $yaml .= $prefix . yaml_key($key) . ":" . PHP_EOL . array_to_yaml($value, $indent + 1);
            }
        } else {
            $yaml .= $prefix . yaml_key($key) . ": " . yaml_scalar($value) . PHP_EOL;
        }
    }
    return $yaml;
}

function write_yaml_file($path, $data) {
    file_put_contents($path, array_to_yaml($data));
}

$company = sanitize_name($_POST["company"] ?? "aitor");
$states = $_POST["states"] ?? [];
$selected = array_flip($states);

// Default structure to avoid Jinja errors
$firewall = [
    "wan" => ["ip" => "10.1.105.47", "mask" => 24, "gateway" => "10.1.105.1", "interface" => "enp0s3"],
    "lan" => ["ip" => "192.168.0.1", "mask" => 24, "interface" => "enp0s8"],
    "dmz" => ["ip" => "192.168.1.1", "mask" => 24, "interface" => "enp0s9"]
];

$proxy = ["ip" => "192.168.1.10", "puerto_customizado" => 80, "interface" => "enp0s3", "mask" => 24];

$web = [
    "hostname" => "serv-web",
    "domain" => "server.es",
    "webroot" => "/var/www/user/server/html",
    "network" => ["address" => "192.168.0.10", "mask" => 24, "gateway" => "192.168.0.1", "dns" => "192.168.0.1", "interface" => "enp0s3"]
];

$dhcp = [
    "server_ip" => "192.168.0.10",
    "server_interface" => "enp0s3",
    "log" => true,
    "interfaces" => ["lan" => ["name" => "enp0s3", "range_start" => "192.168.0.50", "range_end" => "192.168.0.200", "netmask" => "255.255.255.0", "lease_time" => "24h"]],
    "options" => ["gateway" => ["item0" => "192.168.0.1"], "dns" => ["item0" => "192.168.0.1"]]
];

$pkica = [
    "base_dir" => "/etc/pki/ca",
    "ca" => ["country" => "ES", "state" => "Girona", "locality" => "Salt", "organization" => "SaltStack Lab", "organizational_unit" => "IT", "common_name" => "Salt-CA", "days_valid" => 3650, "key_size" => 4096, "digest" => "sha256"],
    "files" => [
        "private_key" => "/etc/pki/ca/private/ca.key.pem", "root_cert" => "/etc/pki/ca/certs/ca.cert.pem", "openssl_config" => "/etc/pki/ca/openssl.cnf",
        "index" => "/etc/pki/ca/index.txt", "serial" => "/etc/pki/ca/serial", "serial_start" => "1000"
    ]
];

$wireguard = ["port" => 51820, "address" => "10.66.66.1/24", "static_lan_ip" => "192.168.0.151/24", "wan_interface" => "enp0s3", "peers" => []];

$zabbix = [
    "db_host" => "192.168.0.10", "db_port" => 3306, "db_name" => "zabbix", "db_user" => "zabbix", "db_pass" => "Z@bb1x_2026!", "db_root" => "M@r1aDB_R00t_2026!",
    "server_ip" => "192.168.0.123", "agent_port" => 10050, "discovery_network" => "192.168.0.0/24"
];

$restic = [
    "password" => "alumnat", "repository" => "rest:http://192.168.0.151:8000/", "port" => 8000, "backup_paths" => ["/etc"],
    "mysql" => ["user" => "saltlogger", "password" => "S@ltL0gg3r_2026!", "host" => "192.168.0.10", "database" => "salt_logs", "port" => 3306, "root_password" => "M@r1aDB_R00t_2026!"]
];

$mysql = ["root_password" => "M@r1aDB_R00t_2026!"];

// Mapping
$minion_states = [
    "minion-05" => array_values(array_filter([isset($selected["firewall"]) ? "firewall" : null, isset($selected["dns"]) ? "dns" : null])),
    "minion-04" => array_values(array_filter([isset($selected["proxy"]) ? "proxy" : null])),
    "minion-02" => array_values(array_filter([isset($selected["webserver"]) ? "wordpress" : null])),
    "minion-07" => array_values(array_filter([isset($selected["zabbix-server"]) ? "zabbix.server" : null, isset($selected["BDD"]) ? "BDD" : null])),
    "minion-08" => array_values(array_filter([isset($selected["wireguard"]) ? "wireguard" : null, isset($selected["restic-server"]) ? "restic.server" : null])),
];

foreach ($minion_states as $m => &$mstates) {
    if (empty($mstates)) continue;
    if (isset($selected["zabbix-server"]) && !in_array("zabbix.server", $mstates)) $mstates[] = "zabbix.agent";
    if (isset($selected["restic-server"])) $mstates[] = "restic.client";
}
unset($mstates);

$active_minions = array_filter($minion_states, fn($s) => !empty($s));

$main = [
    "firewall" => $firewall,
    "dns" => ["recursion" => true, "allow_query" => "127.0.0.1; localhost; 192.168.0.0/24; 192.168.1.0/24; 10.1.105.0/24; 10.66.66.0/24", "forwarders" => ["8.8.8.8"]],
    "service_mapping" => $active_minions,
    "network_nodes" => [
        "minion-05" => ["interfaces" => [["ip" => "10.1.105.47", "mask" => 24, "gateway" => "10.1.105.1", "name" => "enp0s3"]]],
        "minion-02" => ["interfaces" => [["ip" => "192.168.0.10", "mask" => 24, "gateway" => "192.168.0.1", "name" => "enp0s3"]]],
        "minion-04" => ["interfaces" => [["ip" => "192.168.1.10", "mask" => 24, "gateway" => "192.168.1.1", "name" => "enp0s3"]]],
        "minion-07" => ["interfaces" => [["ip" => "192.168.0.123", "mask" => 24, "gateway" => "192.168.0.1", "name" => "enp0s3"]]],
        "minion-08" => ["interfaces" => [["ip" => "192.168.0.151", "mask" => 24, "gateway" => "192.168.0.1", "name" => "enp0s3"]]]
    ]
];

// Conditionally add blocks to $main ONLY if selected
if (isset($selected["proxy"])) { $main["proxy"] = $proxy; }
if (isset($selected["webserver"])) {
    $main["web-server"] = $web;
    $main["mysql"] = $mysql;
    $main["wordpress"] = ["db_name" => "wordpress", "db_user" => "wpuser", "db_pass" => "Wp@2026!", "title" => "Lab SaltStack", "admin_user" => "admin", "admin_pass" => "Admin@2026!", "admin_email" => "admin@server.es"];
}
if (isset($selected["dhcp"])) { $main["dhcp"] = $dhcp; }
if (isset($selected["pkica"])) { $main["pkica"] = $pkica; }
if (isset($selected["wireguard"])) { $main["wireguard"] = $wireguard; }
if (isset($selected["BDD"])) { $main["mysql"] = $mysql; }
if (isset($selected["zabbix-server"])) { $main["zabbix"] = $zabbix; }
if (isset($selected["restic-server"])) { $main["restic"] = $restic; }

$base_dir = "/srv/pillar/customers/" . $company;
if (!is_dir($base_dir)) mkdir($base_dir, 0755, true);
write_yaml_file($base_dir . "/main.sls", $main);

$pillar_top = ["base" => []];
foreach (array_keys($active_minions) as $m) $pillar_top["base"][$m] = ["customers.$company.main"];
write_yaml_file("/srv/pillar/top.sls", $pillar_top);

$salt_top = ["base" => ["*" => ["common"]]];
foreach ($active_minions as $m => $mstates) $salt_top["base"][$m] = $mstates;
write_yaml_file("/srv/salt/top.sls", $salt_top);
$main_yaml    = file_get_contents($base_dir . "/main.sls");
$pillar_top_yaml = file_get_contents("/srv/pillar/top.sls");
$salt_top_yaml   = file_get_contents("/srv/salt/top.sls");
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Configuración Generada</title>
    <style>
        body { font-family: sans-serif; background: #0f172a; color: #f8fafc; padding: 20px; }
        pre { background: #0b1220; padding: 15px; border-radius: 8px; border: 1px solid #334155; overflow: auto; font-size: 13px; }
        .card { max-width: 900px; margin: auto; background: #111827; padding: 24px; border-radius: 12px; }
        h1 { color: #38bdf8; margin-bottom: 4px; }
        h3 { color: #7dd3fc; margin: 20px 0 6px; }
        p  { color: #94a3b8; margin-top: 0; }
        .btn { display: inline-block; padding: 10px 20px; background: #38bdf8; color: #082f49; text-decoration: none; border-radius: 6px; font-weight: bold; margin-top: 20px; }
        .badge { display: inline-block; background: #1e3a5f; color: #7dd3fc; border-radius: 4px; padding: 2px 8px; font-size: 12px; margin-left: 8px; vertical-align: middle; }
    </style>
</head>
<body>
<div class="card">
    <h1>✓ Configuración Generada</h1>
    <p>Archivos generados y escritos en el Salt Master.</p>

    <h3>Pillar: <code>customers/<?php echo htmlspecialchars($company); ?>/main.sls</code> <span class="badge"><?php echo count($active_minions); ?> minions</span></h3>
    <pre><?php echo htmlspecialchars($main_yaml); ?></pre>

    <h3>Pillar Top: <code>/srv/pillar/top.sls</code></h3>
    <pre><?php echo htmlspecialchars($pillar_top_yaml); ?></pre>

    <h3>Salt Top: <code>/srv/salt/top.sls</code></h3>
    <pre><?php echo htmlspecialchars($salt_top_yaml); ?></pre>

    <a href="index.php" class="btn">Volver</a>
</div>
</body>
</html>